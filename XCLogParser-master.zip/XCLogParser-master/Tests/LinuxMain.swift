import XCTest

import XCLogParserTests

var tests = [XCTestCaseEntry]()
tests += XCLogParserTests.__allTests()

XCTMain(tests)
